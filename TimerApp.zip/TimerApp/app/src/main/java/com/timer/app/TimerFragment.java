package com.timer.app;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.google.android.material.switchmaterial.SwitchMaterial;

public class TimerFragment extends Fragment {

    private static final String ARG_TAB = "tab_number";

    private TextView tvTimer;
    private EditText etHours, etMinutes, etSeconds;
    private Button btnSet, btnReset;
    private SwitchMaterial toggleTimer;

    private CountDownTimer countDownTimer;
    private long totalTimeMillis = 0;
    private long timeLeftMillis = 0;
    private boolean isRunning = false;

    public static TimerFragment newInstance(int tabNumber) {
        TimerFragment fragment = new TimerFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_TAB, tabNumber);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_timer, container, false);

        tvTimer = view.findViewById(R.id.tvTimer);
        etHours = view.findViewById(R.id.etHours);
        etMinutes = view.findViewById(R.id.etMinutes);
        etSeconds = view.findViewById(R.id.etSeconds);
        btnSet = view.findViewById(R.id.btnSet);
        btnReset = view.findViewById(R.id.btnReset);
        toggleTimer = view.findViewById(R.id.toggleTimer);

        btnSet.setOnClickListener(v -> setTimer());

        toggleTimer.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                if (timeLeftMillis > 0) {
                    startTimer();
                } else {
                    Toast.makeText(getContext(), "Set waktu dulu!", Toast.LENGTH_SHORT).show();
                    toggleTimer.setChecked(false);
                }
            } else {
                pauseTimer();
            }
        });

        btnReset.setOnClickListener(v -> resetTimer());

        return view;
    }

    private void setTimer() {
        String hStr = etHours.getText().toString().trim();
        String mStr = etMinutes.getText().toString().trim();
        String sStr = etSeconds.getText().toString().trim();

        int hours = hStr.isEmpty() ? 0 : Integer.parseInt(hStr);
        int minutes = mStr.isEmpty() ? 0 : Integer.parseInt(mStr);
        int seconds = sStr.isEmpty() ? 0 : Integer.parseInt(sStr);

        if (minutes >= 60 || seconds >= 60) {
            Toast.makeText(getContext(), "Menit/detik max 59!", Toast.LENGTH_SHORT).show();
            return;
        }

        totalTimeMillis = (hours * 3600L + minutes * 60L + seconds) * 1000L;

        if (totalTimeMillis == 0) {
            Toast.makeText(getContext(), "Masukkan waktu!", Toast.LENGTH_SHORT).show();
            return;
        }

        timeLeftMillis = totalTimeMillis;
        updateDisplay(timeLeftMillis);

        if (isRunning) {
            countDownTimer.cancel();
            isRunning = false;
            toggleTimer.setChecked(false);
        }

        Toast.makeText(getContext(), "Timer diset! Nyalakan toggle untuk mulai.", Toast.LENGTH_SHORT).show();
    }

    private void startTimer() {
        countDownTimer = new CountDownTimer(timeLeftMillis, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timeLeftMillis = millisUntilFinished;
                updateDisplay(millisUntilFinished);
            }

            @Override
            public void onFinish() {
                timeLeftMillis = 0;
                updateDisplay(0);
                isRunning = false;
                toggleTimer.setChecked(false);
                Toast.makeText(getContext(), "⏰ Timer selesai!", Toast.LENGTH_LONG).show();
            }
        }.start();
        isRunning = true;
    }

    private void pauseTimer() {
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        isRunning = false;
    }

    private void resetTimer() {
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        isRunning = false;
        timeLeftMillis = totalTimeMillis;
        updateDisplay(timeLeftMillis);
        toggleTimer.setChecked(false);
    }

    private void updateDisplay(long millis) {
        int hours = (int) (millis / 1000) / 3600;
        int minutes = (int) ((millis / 1000) % 3600) / 60;
        int seconds = (int) (millis / 1000) % 60;
        tvTimer.setText(String.format("%02d:%02d:%02d", hours, minutes, seconds));
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
    }
}
