package com.timer.app;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class TimerPagerAdapter extends FragmentStateAdapter {

    public TimerPagerAdapter(@NonNull FragmentActivity activity) {
        super(activity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        return TimerFragment.newInstance(position + 1);
    }

    @Override
    public int getItemCount() {
        return 5;
    }
}
